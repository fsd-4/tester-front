
export interface Fan{
    id: number,
    nom: string,
    malumot: string
}