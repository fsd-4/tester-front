
export interface Variant{
    id: number,
    matn: string,
    tugri: boolean
}