export const environment = {
  production: true,
  baseApi: "https://idrok.net/api"
};
